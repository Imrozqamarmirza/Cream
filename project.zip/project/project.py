import sys
import csv
from datetime import datetime

print("Welcome to Age Calculator")

def calculate_age(birth_date):
    today = datetime.today()
    age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
    return age

def main():
    check_args()
    try:
        with open(sys.argv[1], 'r') as csvfile:
            reader = csv.DictReader(csvfile)
            birth_dates = {row['names']: row['date_of_birth'] for row in reader}

            check_name(birth_dates)

    except FileNotFoundError:
        sys.exit("File not present")

def check_args():
    if len(sys.argv) < 2:
        sys.exit("Too few arguments")
    if len(sys.argv) > 2:
        sys.exit("Too many arguments")
    if '.csv' not in sys.argv[1]:
        sys.exit("Not a CSV file")

def check_name(birth_dates):
    name = input("Please enter your name: ")

    if name in birth_dates:
        birth_date_str = birth_dates[name]
        birth_date = datetime.strptime(birth_date_str, "%d/%m/%Y")
        age = calculate_age(birth_date)

        years_until_retirement = 65 - age
        if years_until_retirement > 0:
            print(f'{name} is {age} years old and has {years_until_retirement} years until retirement.')
        else:
            print(f"{name} is already retired.")
    else:
        print(f"{name} was not found in the csv file.")

if __name__ == "__main__":
    main()
